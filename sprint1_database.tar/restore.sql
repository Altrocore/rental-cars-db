--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE sprint1;
--
-- Name: sprint1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE sprint1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE sprint1 OWNER TO postgres;

\connect sprint1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: brand; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.brand (
    brand_id integer NOT NULL,
    brand_name character varying(50)
);


ALTER TABLE public.brand OWNER TO postgres;

--
-- Name: brand_brand_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.brand_brand_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.brand_brand_id_seq OWNER TO postgres;

--
-- Name: brand_brand_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.brand_brand_id_seq OWNED BY public.brand.brand_id;


--
-- Name: car; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.car (
    vin character varying(20) NOT NULL,
    make character varying(50),
    model character varying(50),
    year integer,
    price numeric(10,2),
    availability_status character varying(50)
);


ALTER TABLE public.car OWNER TO postgres;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    customer_id integer NOT NULL,
    name character varying(100),
    contact_details character varying(100),
    purchase_history text
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: customer_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customer_customer_id_seq OWNER TO postgres;

--
-- Name: customer_customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_customer_id_seq OWNED BY public.customer.customer_id;


--
-- Name: employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee (
    employee_id integer NOT NULL,
    name character varying(100),
    contact_details character varying(100),
    "position" character varying(50),
    department character varying(50)
);


ALTER TABLE public.employee OWNER TO postgres;

--
-- Name: employee_employee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employee_employee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employee_employee_id_seq OWNER TO postgres;

--
-- Name: employee_employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employee_employee_id_seq OWNED BY public.employee.employee_id;


--
-- Name: maintenancerecord; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.maintenancerecord (
    vin character varying(20),
    maintenance_type character varying(50),
    date date,
    description text
);


ALTER TABLE public.maintenancerecord OWNER TO postgres;

--
-- Name: model; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.model (
    model_id integer NOT NULL,
    model_name character varying(50),
    specifications text
);


ALTER TABLE public.model OWNER TO postgres;

--
-- Name: model_model_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.model_model_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.model_model_id_seq OWNER TO postgres;

--
-- Name: model_model_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.model_model_id_seq OWNED BY public.model.model_id;


--
-- Name: salestransaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.salestransaction (
    transaction_id integer NOT NULL,
    date date,
    car_vin character varying(20),
    customer_id integer,
    total_amount numeric(10,2)
);


ALTER TABLE public.salestransaction OWNER TO postgres;

--
-- Name: salestransaction_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.salestransaction_transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.salestransaction_transaction_id_seq OWNER TO postgres;

--
-- Name: salestransaction_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.salestransaction_transaction_id_seq OWNED BY public.salestransaction.transaction_id;


--
-- Name: serviceappointment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.serviceappointment (
    appointment_id integer NOT NULL,
    date date,
    customer_id integer,
    car_vin character varying(20),
    service_type character varying(50),
    status character varying(50)
);


ALTER TABLE public.serviceappointment OWNER TO postgres;

--
-- Name: serviceappointment_appointment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.serviceappointment_appointment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.serviceappointment_appointment_id_seq OWNER TO postgres;

--
-- Name: serviceappointment_appointment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.serviceappointment_appointment_id_seq OWNED BY public.serviceappointment.appointment_id;


--
-- Name: brand brand_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.brand ALTER COLUMN brand_id SET DEFAULT nextval('public.brand_brand_id_seq'::regclass);


--
-- Name: customer customer_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer ALTER COLUMN customer_id SET DEFAULT nextval('public.customer_customer_id_seq'::regclass);


--
-- Name: employee employee_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee ALTER COLUMN employee_id SET DEFAULT nextval('public.employee_employee_id_seq'::regclass);


--
-- Name: model model_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model ALTER COLUMN model_id SET DEFAULT nextval('public.model_model_id_seq'::regclass);


--
-- Name: salestransaction transaction_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salestransaction ALTER COLUMN transaction_id SET DEFAULT nextval('public.salestransaction_transaction_id_seq'::regclass);


--
-- Name: serviceappointment appointment_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.serviceappointment ALTER COLUMN appointment_id SET DEFAULT nextval('public.serviceappointment_appointment_id_seq'::regclass);


--
-- Data for Name: brand; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.brand (brand_id, brand_name) FROM stdin;
\.
COPY public.brand (brand_id, brand_name) FROM '$$PATH$$/3673.dat';

--
-- Data for Name: car; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.car (vin, make, model, year, price, availability_status) FROM stdin;
\.
COPY public.car (vin, make, model, year, price, availability_status) FROM '$$PATH$$/3662.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (customer_id, name, contact_details, purchase_history) FROM stdin;
\.
COPY public.customer (customer_id, name, contact_details, purchase_history) FROM '$$PATH$$/3664.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee (employee_id, name, contact_details, "position", department) FROM stdin;
\.
COPY public.employee (employee_id, name, contact_details, "position", department) FROM '$$PATH$$/3670.dat';

--
-- Data for Name: maintenancerecord; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.maintenancerecord (vin, maintenance_type, date, description) FROM stdin;
\.
COPY public.maintenancerecord (vin, maintenance_type, date, description) FROM '$$PATH$$/3671.dat';

--
-- Data for Name: model; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.model (model_id, model_name, specifications) FROM stdin;
\.
COPY public.model (model_id, model_name, specifications) FROM '$$PATH$$/3675.dat';

--
-- Data for Name: salestransaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.salestransaction (transaction_id, date, car_vin, customer_id, total_amount) FROM stdin;
\.
COPY public.salestransaction (transaction_id, date, car_vin, customer_id, total_amount) FROM '$$PATH$$/3666.dat';

--
-- Data for Name: serviceappointment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.serviceappointment (appointment_id, date, customer_id, car_vin, service_type, status) FROM stdin;
\.
COPY public.serviceappointment (appointment_id, date, customer_id, car_vin, service_type, status) FROM '$$PATH$$/3668.dat';

--
-- Name: brand_brand_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.brand_brand_id_seq', 4, true);


--
-- Name: customer_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_customer_id_seq', 4, true);


--
-- Name: employee_employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_employee_id_seq', 4, true);


--
-- Name: model_model_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.model_model_id_seq', 4, true);


--
-- Name: salestransaction_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.salestransaction_transaction_id_seq', 4, true);


--
-- Name: serviceappointment_appointment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.serviceappointment_appointment_id_seq', 4, true);


--
-- Name: brand brand_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.brand
    ADD CONSTRAINT brand_pkey PRIMARY KEY (brand_id);


--
-- Name: car car_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.car
    ADD CONSTRAINT car_pkey PRIMARY KEY (vin);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (customer_id);


--
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (employee_id);


--
-- Name: model model_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model
    ADD CONSTRAINT model_pkey PRIMARY KEY (model_id);


--
-- Name: salestransaction salestransaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salestransaction
    ADD CONSTRAINT salestransaction_pkey PRIMARY KEY (transaction_id);


--
-- Name: serviceappointment serviceappointment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.serviceappointment
    ADD CONSTRAINT serviceappointment_pkey PRIMARY KEY (appointment_id);


--
-- Name: idx_brand_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_brand_name ON public.brand USING btree (brand_name);


--
-- Name: idx_car_availability_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_car_availability_status ON public.car USING btree (availability_status);


--
-- Name: idx_car_make; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_car_make ON public.car USING btree (make);


--
-- Name: idx_car_model; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_car_model ON public.car USING btree (model);


--
-- Name: idx_car_year; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_car_year ON public.car USING btree (year);


--
-- Name: idx_customer_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_name ON public.customer USING btree (name);


--
-- Name: idx_employee_department; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_department ON public.employee USING btree (department);


--
-- Name: idx_employee_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_name ON public.employee USING btree (name);


--
-- Name: idx_employee_position; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_position ON public.employee USING btree ("position");


--
-- Name: idx_maintenance_record_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_maintenance_record_date ON public.maintenancerecord USING btree (date);


--
-- Name: idx_maintenance_record_vin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_maintenance_record_vin ON public.maintenancerecord USING btree (vin);


--
-- Name: idx_model_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_model_name ON public.model USING btree (model_name);


--
-- Name: idx_salestransaction_car_vin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_salestransaction_car_vin ON public.salestransaction USING btree (car_vin);


--
-- Name: idx_salestransaction_customer_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_salestransaction_customer_id ON public.salestransaction USING btree (customer_id);


--
-- Name: idx_salestransaction_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_salestransaction_date ON public.salestransaction USING btree (date);


--
-- Name: idx_serviceappointment_car_vin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_serviceappointment_car_vin ON public.serviceappointment USING btree (car_vin);


--
-- Name: idx_serviceappointment_customer_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_serviceappointment_customer_id ON public.serviceappointment USING btree (customer_id);


--
-- Name: idx_serviceappointment_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_serviceappointment_date ON public.serviceappointment USING btree (date);


--
-- Name: maintenancerecord maintenancerecord_vin_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maintenancerecord
    ADD CONSTRAINT maintenancerecord_vin_fkey FOREIGN KEY (vin) REFERENCES public.car(vin);


--
-- Name: salestransaction salestransaction_car_vin_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salestransaction
    ADD CONSTRAINT salestransaction_car_vin_fkey FOREIGN KEY (car_vin) REFERENCES public.car(vin);


--
-- Name: salestransaction salestransaction_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salestransaction
    ADD CONSTRAINT salestransaction_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);


--
-- Name: serviceappointment serviceappointment_car_vin_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.serviceappointment
    ADD CONSTRAINT serviceappointment_car_vin_fkey FOREIGN KEY (car_vin) REFERENCES public.car(vin);


--
-- Name: serviceappointment serviceappointment_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.serviceappointment
    ADD CONSTRAINT serviceappointment_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);


--
-- PostgreSQL database dump complete
--

